﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe9Lista2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double altura;
            double peso;
            string sexo;
            double R;
            
            Console.Write("Informe o sexo M ou F: ");
            sexo = Console.ReadLine();

            Console.Write("Digite o Valor de sua Altura: ");
            altura = Double.Parse(Console.ReadLine());

            Console.Write("Digite o Valor do seu Peso: ");
            peso = Double.Parse(Console.ReadLine());
            
            R = peso / (altura * altura);

            if (sexo == "M")
                if (R < 20)
                    Console.WriteLine("Você está abaixo do peso");
                else
                if (R >= 25)
                    Console.WriteLine("Você está acima do peso.");
                else
                    Console.WriteLine("Você está no peso ideal.");
            else
            if (R < 19)
                Console.WriteLine("Você está abaixo do peso.");
            else
            if (R >= 24)
                Console.WriteLine("Você está acima do peso,");
            else
                Console.WriteLine("Você está no peso ideal.");






    }   }
}
