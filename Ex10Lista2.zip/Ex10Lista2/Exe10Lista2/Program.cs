﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe10Lista2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double P1;
            double P2;
            double R;

               Console.Write("Digite o Valor da P1: ");
               P1 = Double.Parse(Console.ReadLine());
               Console.Write("Digite o Valor da P1: ");
               P2 = Double.Parse(Console.ReadLine());

            R = ((P1 + P2) / 3);

            if (R >= 5)
                Console.WriteLine("Aprovado");
            else            
                Console.WriteLine("Reprovado");
                


        }
    }
}
